var structcolor_data =
[
    [ "value", "structcolor_data.html#a2aeaa87d2597c10d5d568d0e17275103", null ]
];