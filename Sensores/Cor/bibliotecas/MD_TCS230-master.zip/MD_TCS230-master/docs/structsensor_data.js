var structsensor_data =
[
    [ "value", "structsensor_data.html#ae766c0abe2883fde58eec0ed5d1260b6", null ]
];