var class_m_d___t_c_s230 =
[
    [ "MD_TCS230", "class_m_d___t_c_s230.html#ae4c643a132230b3d36ab6c0529e417da", null ],
    [ "MD_TCS230", "class_m_d___t_c_s230.html#aaea00aec4b580311bf41b0dadb859fd1", null ],
    [ "MD_TCS230", "class_m_d___t_c_s230.html#aabfadbaa7c191740c2e52ebb1c577f0d", null ],
    [ "MD_TCS230", "class_m_d___t_c_s230.html#aaba478621975f1afe1aba089d1cd625b", null ],
    [ "~MD_TCS230", "class_m_d___t_c_s230.html#a763b737825a3ebc1c8a27ed0fcebf4a0", null ],
    [ "available", "class_m_d___t_c_s230.html#aee06e75144133080e8cd0ec566f9d606", null ],
    [ "begin", "class_m_d___t_c_s230.html#a60beccb7522c8866b913232bd766611f", null ],
    [ "getRaw", "class_m_d___t_c_s230.html#abf89a61d5754935d0db2c88b06cd2860", null ],
    [ "getRGB", "class_m_d___t_c_s230.html#ae8826a9d26530b625506c8d8b5964a4e", null ],
    [ "read", "class_m_d___t_c_s230.html#a05b5fc39125498a17ac1949a7335dcf9", null ],
    [ "readSingle", "class_m_d___t_c_s230.html#a0f26eaaa609cbfacac89d0cf9afc4942", null ],
    [ "setDarkCal", "class_m_d___t_c_s230.html#ab9f6199eb47082f89e94fb1dcfca145c", null ],
    [ "setEnable", "class_m_d___t_c_s230.html#a9e038b9cd84d1aca4a1fe4adf689fad3", null ],
    [ "setFilter", "class_m_d___t_c_s230.html#a5323e7d8e6fcacf5966163c27c95767b", null ],
    [ "setFrequency", "class_m_d___t_c_s230.html#a50106bee42eb52bffa4a5b690c327f3a", null ],
    [ "setSampling", "class_m_d___t_c_s230.html#a466345be9c755bad004df694660e1ae6", null ],
    [ "setWhiteCal", "class_m_d___t_c_s230.html#ac76afdd0a83baefafb43fa8670460763", null ]
];