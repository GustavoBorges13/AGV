var searchData=
[
  ['getraw',['getRaw',['../class_m_d___t_c_s230.html#abf89a61d5754935d0db2c88b06cd2860',1,'MD_TCS230']]],
  ['getrgb',['getRGB',['../class_m_d___t_c_s230.html#ae8826a9d26530b625506c8d8b5964a4e',1,'MD_TCS230']]]
];
