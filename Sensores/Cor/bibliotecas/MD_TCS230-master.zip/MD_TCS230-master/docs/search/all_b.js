var searchData=
[
  ['value',['value',['../structsensor_data.html#ae766c0abe2883fde58eec0ed5d1260b6',1,'sensorData::value()'],['../structcolor_data.html#a2aeaa87d2597c10d5d568d0e17275103',1,'colorData::value()']]]
];
