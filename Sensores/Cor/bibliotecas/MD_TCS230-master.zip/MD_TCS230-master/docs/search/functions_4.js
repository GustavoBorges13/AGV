var searchData=
[
  ['read',['read',['../class_m_d___t_c_s230.html#a05b5fc39125498a17ac1949a7335dcf9',1,'MD_TCS230']]],
  ['readsingle',['readSingle',['../class_m_d___t_c_s230.html#a0f26eaaa609cbfacac89d0cf9afc4942',1,'MD_TCS230']]]
];
