var searchData=
[
  ['tcs230_5ffreq_5fhi',['TCS230_FREQ_HI',['../_m_d___t_c_s230_8h.html#aed4aa7cad67adf935a962817a9c4794f',1,'MD_TCS230.h']]],
  ['tcs230_5ffreq_5flo',['TCS230_FREQ_LO',['../_m_d___t_c_s230_8h.html#af58494665cc7f7e732156633a3be1364',1,'MD_TCS230.h']]],
  ['tcs230_5ffreq_5fmid',['TCS230_FREQ_MID',['../_m_d___t_c_s230_8h.html#aa98a5f57d6c2e42a1394dbc1c2f0c045',1,'MD_TCS230.h']]],
  ['tcs230_5ffreq_5foff',['TCS230_FREQ_OFF',['../_m_d___t_c_s230_8h.html#a4d57d31b92b18b1796aa7b70979e3606',1,'MD_TCS230.h']]],
  ['tcs230_5frgb_5fb',['TCS230_RGB_B',['../_m_d___t_c_s230_8h.html#a9cdd6ac302a1ce150aedb86b8ce419d2',1,'MD_TCS230.h']]],
  ['tcs230_5frgb_5fg',['TCS230_RGB_G',['../_m_d___t_c_s230_8h.html#a9726e262b8e05d26eb2b4007c3723c45',1,'MD_TCS230.h']]],
  ['tcs230_5frgb_5fr',['TCS230_RGB_R',['../_m_d___t_c_s230_8h.html#ac3935ee2d9e1bb88574d56b315f7429c',1,'MD_TCS230.h']]],
  ['tcs230_5frgb_5fx',['TCS230_RGB_X',['../_m_d___t_c_s230_8h.html#abd5cf9a828f724cebc4c8187d841b455',1,'MD_TCS230.h']]]
];
