var searchData=
[
  ['no_5fpin',['NO_PIN',['../_m_d___t_c_s230_8h.html#a762dbd131e5a17b098ed61330b268fd7',1,'MD_TCS230.h']]]
];
