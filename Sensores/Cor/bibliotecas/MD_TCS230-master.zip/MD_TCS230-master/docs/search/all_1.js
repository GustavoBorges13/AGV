var searchData=
[
  ['begin',['begin',['../class_m_d___t_c_s230.html#a60beccb7522c8866b913232bd766611f',1,'MD_TCS230']]]
];
